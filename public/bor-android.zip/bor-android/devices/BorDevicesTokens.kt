package bor.brand

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Opt-in Devices profile; not a mandatory Bor palette.
object BorDevicesTokens {
    object Light {
        val primary = Color(0xFF171717)
        val onPrimary = Color(0xFFFAFAFA)
        val secondary = Color(0xFFF5F5F5)
        val onSecondary = Color(0xFF171717)
        val secondaryContainer = Color(0xFFF5F5F5)
        val onSecondaryContainer = Color(0xFF171717)
        val background = Color(0xFFF5F5F5)
        val onBackground = Color(0xFF0A0A0A)
        val onSurface = Color(0xFF0A0A0A)
        val surfaceVariant = Color(0xFFF5F5F5)
        val onSurfaceVariant = Color(0xFF737373)
        val surfaceContainerHighest = Color(0xFFF5F5F5)
        val outline = Color(0xFFA3A3A3)
        val outlineVariant = Color(0xFFE5E5E5)
        val surface = Color(0xFFFFFFFF)
        val surfaceContainer = Color(0xFFFFFFFF)
    }
    object Dark {
        val primary = Color(0xFFE5E5E5)
        val onPrimary = Color(0xFF171717)
        val secondary = Color(0xFF404040)
        val onSecondary = Color(0xFFFAFAFA)
        val secondaryContainer = Color(0xFF262626)
        val onSecondaryContainer = Color(0xFFFAFAFA)
        val background = Color(0xFF0A0A0A)
        val onBackground = Color(0xFFFAFAFA)
        val surface = Color(0xFF171717)
        val onSurface = Color(0xFFFAFAFA)
        val surfaceVariant = Color(0xFF262626)
        val onSurfaceVariant = Color(0xFFA3A3A3)
        val surfaceContainer = Color(0xFF171717)
        val surfaceContainerHighest = Color(0xFF262626)
        val outline = Color(0xFF525252)
        val outlineVariant = Color(0xFF303030)
    }
    object Radius {
        val extraSmall = 6.dp
        val small = 8.dp
        val medium = 24.dp
        val large = 28.dp
        val extraLarge = 32.dp
    }
    object Layout {
        val screenInset = 20.dp
        val cardInset = 24.dp
        val contentGap = 12.dp
        val compactGap = 8.dp
    }
}
